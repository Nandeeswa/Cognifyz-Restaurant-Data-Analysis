# Cognifyz Data Analysis Internship - Restaurant Dataset

## Folder structure
- data/     -> "Dataset .csv" (the restaurant dataset)
- code/     -> level1_analysis.py, level2_analysis.py, level3_analysis.py, verify_results.py
- charts/   -> all charts (PNG) + interactive map (l2t3_restaurant_map.html)
- tables/   -> result tables (CSV) and results (JSON) used in the report
- report/   -> Cognifyz_Internship_Report.docx and .pdf (build_report.js is the script that made them)

## 1. Install (Python 3.9 or newer)
    pip install -r requirements.txt

## 2. Run (VS Code or terminal) - run from inside the "code" folder
    cd code
    python level1_analysis.py
    python level2_analysis.py
    python level3_analysis.py
    python verify_results.py

Each script reads ../data/Dataset .csv and writes charts to ../charts and tables to ../tables.
verify_results.py recalculates the key results independently from the raw CSV and prints OK or
MISMATCH for each one. It should end with "ALL CHECKS PASSED".

## 3. Run as notebook cells
Each script is divided into blocks by "# %%" lines. In VS Code (with the Python/Jupyter extensions)
click "Run Cell" above a block. To use a Jupyter Notebook, copy each block into its own cell and
keep the helper at the top. If you run it inside a notebook, the scripts automatically use
BASE = Path("..") so start the notebook from the "code" folder.

## Method notes
- Unrated restaurants (Aggregate rating = 0 / "Not rated") are excluded from every average rating.
- All rounding is half-up (4.475 -> 4.48), done once from the unrounded value, by the helper
  function round_half_up() at the top of each script.
- Level 3 Task 1 (reviews) cannot be done: the dataset has no review text column.
